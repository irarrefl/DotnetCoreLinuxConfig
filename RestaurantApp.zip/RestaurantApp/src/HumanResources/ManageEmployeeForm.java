package HumanResources;

import Examen1.*;
import Application.TallerService;
import Domain.Taller;
import FormTools.ComboboxDataSetter;
import FormTools.JTableManager;
import com.formdev.flatlaf.FlatDarkLaf;
import com.jtattoo.plaf.hifi.HiFiLookAndFeel;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Properties;
import javax.swing.JOptionPane;
import javax.swing.UIManager;

import Application.IService;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import javax.swing.RowFilter;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;

public final class ManageEmployeeForm extends javax.swing.JFrame implements ActionListener,
        MouseListener, KeyListener {

    ComboboxDataSetter ComboboxDataSetter;

    IService<Taller> tallerService;

    JTableManager jtableManager;

    public ManageEmployeeForm() {

        initComponents();

        tallerService = new TallerService();
        TMarcas.addItem("");
        TMarcas.addItem("Toyota");
        TMarcas.addItem("Chebrolet");
        setLocationRelativeTo(null);

        UpdateDataTable();
        EnableInput(false);

        AddListeners();
        
      //  ExecuteThreads();
    }
    
    public synchronized void ExecuteThreads()
    {
      try{
            Timer timer = new Timer();
        
        
        TimerTask task = new TimerTask(){
            @Override
            public void run() {
                UpdateDataTable();
            }
            
        };
        
        timer.schedule(task, 10,1000);
        
        
        Thread t = new Thread(task);
        t.start();
      }
      catch(Exception e){System.out.print(e.getCause());}
    }

    private final ScheduledExecutorService scheduler = Executors.newScheduledThreadPool(1);

    public void UpdateDataTable() {

          ArrayList<Taller> t = tallerService.GetData(1);
            
            jtableManager = new JTableManager(EmployeesTable);

            jtableManager.FillTable(t);

    }

    public void EnableControl(boolean... control1) {

        EmployeesTable.setEnabled(control1[0]);
        if (control1.length > 1) {
            NewButton.setEnabled(control1[1]);
            EditButton.setEnabled(control1[2]);
            DelButton.setEnabled(control1[3]);
            RestButton.setEnabled(control1[4]);
        }

    }

    public void EnableInput(boolean disable) {
        IdentidadT.setEnabled(disable);
        TipEquipo.setEnabled(disable);
        NombreCliente.setEnabled(disable);
        TMarcas.setEnabled(disable);
        NomReceptor.setEditable(disable);
        DetProblema.setEnabled(disable);
        ModEquipo.setEnabled(disable);
        //Observation.setEnabled(disable);
    }

    public void AddListeners() {
        GuardarButton.addActionListener(this);
        LimpiarButton.addActionListener(this);
        NewButton.addActionListener(this);
        EditButton.addActionListener(this);
        DelButton.addActionListener(this);
        RestButton.addActionListener(this);

        EmployeesTable.addMouseListener(this);

        Buscador.addKeyListener(this);

    }

    public Taller GetModel() {

        Taller taller = new Taller() {
            {
                Identidad = IdentidadT.getText();
                Nombre = NombreCliente.getText();
                TipoEquipo = TipEquipo.getText();
                Marcas = TMarcas.getSelectedItem().toString();
                NombreReceptor = NomReceptor.getText();
                DetalleProblema = DetProblema.getText();
                ModeloEquipo = ModEquipo.getText();
               // Observacion = Observation.getText();
            }
        };

        boolean isAnyParameterEmpty = IsInputDataEmpty(taller.Identidad) || 
                IsInputDataEmpty(taller.Nombre) || 
                IsInputDataEmpty(taller.TipoEquipo) ||
                IsInputDataEmpty(taller.Marcas) ||
                IsInputDataEmpty(taller.NombreReceptor)  ||
                IsInputDataEmpty(taller.DetalleProblema) || 
                IsInputDataEmpty(taller.ModeloEquipo)||
                IsInputDataEmpty(taller.Observacion);

        if (isAnyParameterEmpty) {
            JOptionPane.showMessageDialog(null, "Alguno de los campos está vacio o tiene formato incorrecto");
            return null;
        }

        return taller;
    }

    boolean IsInputDataEmpty(Object s) {
        String x = "";
        return s == null || s.equals(x);

    }

    public void HandleState(ActionEvent evt) {
        String crudState = GuardarButton.getText();

        if (evt.getSource() == GuardarButton) {

            Taller orden = GetModel();
            switch (crudState) {
                case "Guardar":

                    if (IsInputDataEmpty(orden)) 
                    {
                        return;
                    }
                    
                    tallerService.SaveData(orden);
                    UpdateDataTable();
                    break;

                case "Editar":

                    tallerService.EditData(orden);
                    UpdateDataTable();
                    break;

                case "Eliminar":

                    tallerService.UpdateData(orden, "inactive");
                    UpdateDataTable();
                    break;

                case "Restaurar":

                    break;
            }
        }
    }

    public void Limpiar() {
        String disable = "";
        IdentidadT.setText(disable);
        TipEquipo.setText(disable);
        NombreCliente.setText(disable);
        TMarcas.setSelectedItem(disable);
        NomReceptor.setText(disable);
        DetProblema.setText(disable);
        ModEquipo.setText(disable);
       // Observation.setText(disable);
    }

    public void HandleInputs(ActionEvent evt) {
        if (evt.getSource() == LimpiarButton) {
            Limpiar();
        }

        //crud
        if (evt.getSource() == NewButton) {

            GuardarButton.setText("Guardar");

            EnableInput(true);
            EnableControl(false);
            Limpiar();

        } else {

            Limpiar();
        }

        if (evt.getSource() == EditButton) {

            EnableInput(true);
            EnableControl(true);

            IdentidadT.setEnabled(false);

            GuardarButton.setText("Editar");
        }

        if (evt.getSource() == DelButton) {
            //RenderActives();
            EnableInput(false);
            EnableControl(true);
            GuardarButton.setText("Eliminar");
        }

        if (evt.getSource() == RestButton) {

            EnableInput(false);
            EnableControl(true);

            RestoreWindow restoreData = new RestoreWindow();
            restoreData.setVisible(true);

        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {

        HandleState(e);
        HandleInputs(e);
    }

    public void SetInputData(Taller taller) {
        IdentidadT.setText(taller.Identidad);

        TipEquipo.setText(taller.TipoEquipo);
        NombreCliente.setText(taller.Nombre);
        TMarcas.setSelectedItem(taller.Marcas);
        NomReceptor.setText(taller.NombreReceptor);
        DetProblema.setText(taller.DetalleProblema);
        ModEquipo.setText(taller.ModeloEquipo);
        //Observation.setText(taller.Observacion);
    }

    @Override
    public void mouseClicked(MouseEvent e) {

        DefaultTableModel mod = (DefaultTableModel) EmployeesTable.getModel();

        int index = EmployeesTable.getSelectedRow();
        boolean isTableDisabled = index == -1 ? true : false;

        if (isTableDisabled) {
            return;
        }

        Taller taller = new Taller() {
            {
                Identidad = mod.getValueAt(index, 0).toString();
                Nombre = mod.getValueAt(index, 1).toString();
                TipoEquipo = mod.getValueAt(index, 2).toString();
                Marcas = mod.getValueAt(index, 3).toString();
                NombreReceptor = mod.getValueAt(index, 4).toString();
                DetalleProblema = mod.getValueAt(index, 5).toString();
                ModeloEquipo = mod.getValueAt(index, 6).toString();
                Observacion = mod.getValueAt(index, 7).toString();
                IsActive = mod.getValueAt(index, 8).toString();
            }
        };

        SetInputData(taller);

    }

    @Override
    public void mousePressed(MouseEvent e) {

    }

    @Override
    public void mouseReleased(MouseEvent e) {

    }

    @Override
    public void mouseEntered(MouseEvent e) {

    }

    @Override
    public void mouseExited(MouseEvent e) {

    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        NewButton = new javax.swing.JButton();
        DelButton = new javax.swing.JButton();
        EditButton = new javax.swing.JButton();
        RestButton = new javax.swing.JButton();
        jPanel4 = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        TipEquipo = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        TMarcas = new javax.swing.JComboBox<>();
        IdentidadT = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        NomReceptor = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        DetProblema = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        ModEquipo = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        NombreCliente = new javax.swing.JTextField();
        GuardarButton = new javax.swing.JButton();
        LimpiarButton = new javax.swing.JButton();
        jLabel13 = new javax.swing.JLabel();
        jDateChooser1 = new com.toedter.calendar.JDateChooser();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        TipEquipo1 = new javax.swing.JTextField();
        NombreCliente1 = new javax.swing.JTextField();
        jPanel3 = new javax.swing.JPanel();
        Buscador = new javax.swing.JTextField();
        jLabel12 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        EmployeesTable = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(153, 102, 255));

        jLabel1.setBackground(new java.awt.Color(0, 0, 0));
        jLabel1.setFont(new java.awt.Font("Franklin Gothic Medium", 0, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 0, 0));
        jLabel1.setText("Administrar empleados");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(360, 360, 360)
                .addComponent(jLabel1)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addContainerGap())
        );

        jPanel2.setBackground(new java.awt.Color(204, 204, 204));

        NewButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/267-plus.png"))); // NOI18N
        NewButton.setText("Nuevo");
        NewButton.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        NewButton.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);

        DelButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/173-bin.png"))); // NOI18N
        DelButton.setText("Eliminar");
        DelButton.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        DelButton.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);

        EditButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/006-pencil.png"))); // NOI18N
        EditButton.setText("Editar");
        EditButton.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        EditButton.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);

        RestButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/133-spinner11.png"))); // NOI18N
        RestButton.setText("Restaurar");
        RestButton.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        RestButton.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(NewButton)
                .addGap(18, 18, 18)
                .addComponent(DelButton)
                .addGap(18, 18, 18)
                .addComponent(EditButton)
                .addGap(18, 18, 18)
                .addComponent(RestButton)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(RestButton)
                    .addComponent(EditButton)
                    .addComponent(DelButton)
                    .addComponent(NewButton))
                .addContainerGap())
        );

        jPanel4.setBackground(new java.awt.Color(51, 51, 51));
        jPanel4.setBorder(javax.swing.BorderFactory.createTitledBorder("Usuario"));

        jLabel5.setText("Primer nombre");

        jLabel8.setText("Sexo");

        jLabel7.setText("Seguro nombre");

        jLabel6.setText("Cargo empleado");

        jLabel9.setText("Direccion");

        jLabel10.setText("Correo electronico");

        jLabel11.setText("Fecha de nacimiento");

        GuardarButton.setBackground(new java.awt.Color(153, 255, 153));
        GuardarButton.setForeground(new java.awt.Color(0, 0, 0));
        GuardarButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/099-floppy-disk.png"))); // NOI18N
        GuardarButton.setText("Guardar");
        GuardarButton.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        GuardarButton.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        GuardarButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                GuardarButtonActionPerformed(evt);
            }
        });

        LimpiarButton.setBackground(new java.awt.Color(255, 153, 102));
        LimpiarButton.setForeground(new java.awt.Color(0, 0, 0));
        LimpiarButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/099-floppy-disk.png"))); // NOI18N
        LimpiarButton.setText("Limpiar");
        LimpiarButton.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        LimpiarButton.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);

        jLabel13.setText("Identidad");

        jLabel14.setText("Primer apellido");

        jLabel15.setText("Segundo apellido");

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addComponent(LimpiarButton, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(GuardarButton, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(ModEquipo, javax.swing.GroupLayout.PREFERRED_SIZE, 168, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel10))
                        .addGap(30, 30, 30)
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel11)
                            .addComponent(jDateChooser1, javax.swing.GroupLayout.PREFERRED_SIZE, 168, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel8)
                            .addComponent(TMarcas, javax.swing.GroupLayout.PREFERRED_SIZE, 168, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel5)
                            .addComponent(NombreCliente, javax.swing.GroupLayout.PREFERRED_SIZE, 168, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(30, 30, 30)
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel13)
                            .addComponent(IdentidadT, javax.swing.GroupLayout.PREFERRED_SIZE, 168, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(TipEquipo, javax.swing.GroupLayout.PREFERRED_SIZE, 168, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel7))
                        .addGap(32, 32, 32)
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel4Layout.createSequentialGroup()
                                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel6)
                                    .addComponent(NomReceptor, javax.swing.GroupLayout.PREFERRED_SIZE, 168, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(24, 24, 24)
                                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(DetProblema, javax.swing.GroupLayout.PREFERRED_SIZE, 168, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel9)))
                            .addGroup(jPanel4Layout.createSequentialGroup()
                                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel14)
                                    .addComponent(NombreCliente1, javax.swing.GroupLayout.PREFERRED_SIZE, 168, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(24, 24, 24)
                                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(TipEquipo1, javax.swing.GroupLayout.PREFERRED_SIZE, 168, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel15))))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addComponent(jLabel5)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(NombreCliente, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(19, 19, 19)
                        .addComponent(jLabel8)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(TMarcas, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel4Layout.createSequentialGroup()
                                .addComponent(jLabel7)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(TipEquipo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel14)
                                    .addComponent(jLabel15))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(TipEquipo1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(NombreCliente1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addGap(19, 19, 19)
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(jPanel4Layout.createSequentialGroup()
                                .addComponent(jLabel13)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(IdentidadT, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel4Layout.createSequentialGroup()
                                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel6)
                                    .addComponent(jLabel9))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(DetProblema, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(NomReceptor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))))
                .addGap(27, 27, 27)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel11)
                    .addComponent(jLabel10))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(ModEquipo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jDateChooser1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 39, Short.MAX_VALUE)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(LimpiarButton, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(GuardarButton, javax.swing.GroupLayout.Alignment.TRAILING))
                .addContainerGap())
        );

        jPanel3.setBackground(new java.awt.Color(153, 153, 153));

        Buscador.setFont(new java.awt.Font("Dialog", 0, 14)); // NOI18N

        jLabel12.setForeground(new java.awt.Color(0, 0, 0));
        jLabel12.setText("Buscar");

        EmployeesTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "IdTaller", "NombreCliente", "FechaRecepcion", "TipoEquipo", "MarcaEquipo", "ModeloEquipo", "DetalleProblema", "NombreReceptor", "Observaciones"
            }
        ));
        jScrollPane1.setViewportView(EmployeesTable);

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 951, Short.MAX_VALUE)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 168, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(Buscador, javax.swing.GroupLayout.PREFERRED_SIZE, 203, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(6, 6, 6)
                .addComponent(jLabel12)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(Buscador, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 102, Short.MAX_VALUE)
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel3, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(8, 8, 8))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void GuardarButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_GuardarButtonActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_GuardarButtonActionPerformed

    public static void main(String args[]) {

        try {
            Properties props = new Properties();
            props.put("logoString", "");
            HiFiLookAndFeel.setCurrentTheme(props);

            String library = "com.formdev.flatlaf";

            UIManager.setLookAndFeel(new FlatDarkLaf());

        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ManageEmployeeForm
                        .class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }

        java.awt.EventQueue.invokeLater(() -> {
            new ManageEmployeeForm().setVisible(true);
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField Buscador;
    private javax.swing.JButton DelButton;
    private javax.swing.JTextField DetProblema;
    private javax.swing.JButton EditButton;
    private javax.swing.JTable EmployeesTable;
    private javax.swing.JButton GuardarButton;
    private javax.swing.JTextField IdentidadT;
    private javax.swing.JButton LimpiarButton;
    private javax.swing.JTextField ModEquipo;
    private javax.swing.JButton NewButton;
    private javax.swing.JTextField NomReceptor;
    private javax.swing.JTextField NombreCliente;
    private javax.swing.JTextField NombreCliente1;
    private javax.swing.JButton RestButton;
    private javax.swing.JComboBox<String> TMarcas;
    private javax.swing.JTextField TipEquipo;
    private javax.swing.JTextField TipEquipo1;
    private com.toedter.calendar.JDateChooser jDateChooser1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JScrollPane jScrollPane1;
    // End of variables declaration//GEN-END:variables

    @Override
    public void keyTyped(KeyEvent e) {

    }

    @Override
    public void keyPressed(KeyEvent e) {

    }

    @Override
    public void keyReleased(KeyEvent e) {
        DefaultTableModel table = (DefaultTableModel) EmployeesTable.getModel();

        String busqueda = Buscador.getText();

        TableRowSorter<DefaultTableModel> tableRow = 
                        new TableRowSorter<DefaultTableModel>(table);

        EmployeesTable.setRowSorter(tableRow);

        tableRow.setRowFilter(RowFilter.regexFilter(busqueda));
    }

}
