/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Application;

import Domain.Taller;
import Infrastructure.Conexion;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;

/**
 *
 * @author khelpix
 */
public class TallerService extends IService<Taller>{


    private String table;
    
    public TallerService(){
        table = "Usuarios";
    }
    @Override
    public void SaveData(Taller command) {
      
           String sql = "{ call InsertTaller(?,?,?,?,?,?,?,?) }";
        try {
            
        
            final Connection con = new Conexion().getConexion();
            CallableStatement s1 = con.prepareCall(sql);
           
            
            s1.setString(1, command.Identidad);
            s1.setString(2, command.Nombre);
            s1.setString(3, command.TipoEquipo);
            s1.setString(4, command.Marcas);
            s1.setString(5, command.NombreReceptor);
            s1.setString(6, command.DetalleProblema);
            s1.setString(7, command.ModeloEquipo);
            s1.setString(8, command.Observacion);
           
            
            boolean queryFailed = s1.executeUpdate() == 0 ? true: false;
            
            if(queryFailed){
                JOptionPane.showMessageDialog(null,"Error en el procedure" );
                return ;
            }
            
             JOptionPane.showMessageDialog(null,"Se insertó correctmente" );
                con.close();

        } catch (final SQLException exp) {
            JOptionPane.showMessageDialog(null, "se capturo" + exp.toString(), "El catch capturo", 0);
            System.exit(0);
            return ;
        }
    }

    @Override
    public ArrayList<Taller> GetData(int state) {
        
              String sql = ""; //= "select * from  Taller where Estado = '"+state+"';";
              
              sql += "select * from ";
              sql += table + " where " + " EstaActivo = ";
              sql += ""+state+";";
              
              
             // String sql = " {call GetDataByState(?)}";
              ArrayList<Taller> infoTaller = new ArrayList<Taller>();
              
              
              
        try {
             final Connection con = new Conexion().getConexion();
            // CallableStatement s1 = con.prepareCall(sql);
           Statement s1 = con.createStatement();
           /* s1.setString(1, "active");
           
           
           final ResultSet rs = s1.executeQuery();*/
            
               // ResultSet rs = s1.getResultSet();
                ResultSet rs = s1.executeQuery(sql);
                while (rs.next()) {
                 
                    infoTaller.add(new Taller(){{
                        Identidad = rs.getString("Identidad");
                        Nombre = rs.getString("Nombre");
                        TipoEquipo = rs.getString("TipoEquipo");
                        Marcas = rs.getString("Marcas");
                        NombreReceptor = rs.getString("NombreReceptor");
                        DetalleProblema = rs.getString("DetalleProblema");
                        ModeloEquipo = rs.getString("ModeloEquipo");
                        Observacion = rs.getString("Observacion");
                        IsActive = rs.getString("Estado");
                    }});
                
            }

            con.close();

            return infoTaller;
        } catch (final SQLException exp) {
            JOptionPane.showMessageDialog(null, "se capturo" + exp.toString(), "El catch capturo", 0);
            System.exit(0);
            return null;
        }
    }

    @Override
    public void EditData(Taller command) {
          String sql = "{ call UpdateTaller(?,?,?,?,?,?,?,?,?) }";
        try {
            
        
            final Connection con = new Conexion().getConexion();
            CallableStatement s1 = con.prepareCall(sql);
           
            
            s1.setString(1, command.Identidad);
            s1.setString(2, command.Nombre);
            s1.setString(3, command.TipoEquipo);
            s1.setString(4, command.Marcas);
            s1.setString(5, command.NombreReceptor);
            s1.setString(6, command.DetalleProblema);
            s1.setString(7, command.ModeloEquipo);
            s1.setString(8, command.Observacion);
            s1.setString(9, "active");
            
            boolean queryFailed = s1.executeUpdate() == 0 ? true: false;
            
            if(queryFailed){
                JOptionPane.showMessageDialog(null,"no se actualizo nada" );
                return ;
            }
            
             JOptionPane.showMessageDialog(null,"Se editó correctmente" );
                con.close();

        } catch (final SQLException exp) {
            JOptionPane.showMessageDialog(null, "se capturo" + exp.toString(), "El catch capturo", 0);
            System.exit(0);
            return ;
        }
    }

    @Override
    public void UpdateData(Taller command, String state) 
    {
          String sql = "{ call UpdateStateTaller(?,?) }";
        try {
            
        
            final Connection con = new Conexion().getConexion();
            CallableStatement s1 = con.prepareCall(sql);
           
            
            s1.setString(1, command.Identidad);

            s1.setString(2, state);
           
            
            boolean queryFailed = s1.executeUpdate() == 0 ? true: false;
            
            if(queryFailed){
                JOptionPane.showMessageDialog(null,"Error en el procedure" );
                return ;
            }
            
             JOptionPane.showMessageDialog(null,"Se eliminó correctmente" );
                con.close();

        } catch (final SQLException exp) {
            JOptionPane.showMessageDialog(null, "se capturo" + exp.toString(), "El catch capturo", 0);
            System.exit(0);
            return ;
        }
    }
    
}
