/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Domain;

/**
 *
 * @author khelpix
 */
public class Taller

{
       public String Identidad;
       public String LastId;
       public String Nombre;
        public String TipoEquipo;
      public String  Marcas;
      public String  NombreReceptor;
     public String   DetalleProblema;
      public String  ModeloEquipo;
      public String  Observacion;
      
      public String IsActive;
}
