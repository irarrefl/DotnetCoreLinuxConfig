package Infrastructure;

import SharedKernel.Console;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import javax.swing.JOptionPane;

public class Conexion {

    private final String url;
    private final String user;
    private final String pass;
    private final String db;
    private final String localizacion;

    public Conexion() {

        final String[] data = LectorDeArchivos.ExtractConfig();

        Config config = LectorDeArchivos.GetUserConfig(data);
        db = config.DbName;
        user = config.Usuario;
        pass = config.Pass;
        localizacion = config.DbLocation;
        
        String mariadb = "mariadb:";
        String mysql = "mysql:";
        int port = 3306;
        
        String routeLocation = "//"+localizacion+":";
        String portConnection = port+"/";
        
    
        
        StringBuilder conBuilder = new StringBuilder();
        conBuilder.append("jdbc:");
       conBuilder.append(mariadb);
        conBuilder.append(routeLocation);
       conBuilder.append(portConnection);
        conBuilder.append(db);
        
        
        url = conBuilder.toString();
            
                

    }
    
    public static void main(String[] args)
    {
        Conexion con = new Conexion();
        
        Console.Log(con.url);
    }
    

    public boolean ExistConnection() {
        return getConexion() != null;
    }

    public Connection getConexion() {
        try {
            try {
                Connection conexion = null;

                //Establecimos la zona horaria del servidor a la de honduras SET GLOBAL time_zone = '-6:00';
                String mariadbDriver = "org.mariadb.jdbc.Driver";
                String mysqlDriver = "com.mysql.jdbc.Driver";
                
                Class.forName(mariadbDriver);
                conexion = DriverManager.getConnection(url, user, pass);
                return conexion;
            } catch (ClassNotFoundException | SQLException e) {
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "ERROR EN CONEXION DE RED A BASE DE DATOS\n"
                    + e.getMessage(),
                    "Conexion a Base de Datos Incorrecta", 0);
            
            
        }
        return null;
    }
}
