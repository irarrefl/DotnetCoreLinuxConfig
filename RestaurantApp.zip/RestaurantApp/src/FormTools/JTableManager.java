/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package FormTools;

import Domain.Taller;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import java.util.ArrayList;

/**
 *
 * @author khelpix
 */
public class JTableManager<T> implements MouseListener{



    JTable Table;

    DefaultTableModel EmployeeTableModel;

    String Columns[] = {
        "Identidad",
        "Nombre",
        "TipoEquipo",
        "Marcas",
        "NombreReceptor",
        "DetalleProblema",
        "ModeloEquipo",
        "Observacion"
            ,"Estado"
    };
    
    public String GetSelectedData() {
        int fila = Table.getSelectedRow();
        int col = Table.getSelectedColumn();
        String id = "";
        if (col == 0) {
            id = EmployeeTableModel.getValueAt(fila, col).toString();
        }
        return id;
    }

    
    public JTableManager(JTable table) {
        
        Table = table;
        
        EmployeeTableModel = new DefaultTableModel() {
            public boolean isCellEditable(final int row, final int column) {
                return false;
            }
        };
        
        for (final String col : Columns) {
            EmployeeTableModel.addColumn(col);

        }

        Table.setModel(EmployeeTableModel);
    }


    public <T> void FillTable(ArrayList<Taller> arr) {
        
        
        arr.forEach(data -> {
            
            EmployeeTableModel.addRow(new String[]{
                data.Identidad,
                data.Nombre,
                data.TipoEquipo,
                data.Marcas,
                data.NombreReceptor,
                data.DetalleProblema,
                data.ModeloEquipo,
                data.Observacion,
                data.IsActive
            });
        });
        
            
        Table.setModel(EmployeeTableModel);

       
    }


    public void ClearTable() {
        final DefaultTableModel dmodel = (DefaultTableModel) Table.getModel();
        while (dmodel.getRowCount() > 0) {
            dmodel.removeRow(0);
        }
    }

    @Override
    public void mouseClicked(MouseEvent e) {
        
        DefaultTableModel mod  = (DefaultTableModel)Table.getModel();
        
        int index = Table.getSelectedRow();  


            String id = mod.getValueAt(index, 0).toString();

           System.out.println(id);
        
        
         
    }

    @Override
    public void mousePressed(MouseEvent e) {
        
    }

    @Override
    public void mouseReleased(MouseEvent e) {
        
    }

    @Override
    public void mouseEntered(MouseEvent e) {
       
    }

    @Override
    public void mouseExited(MouseEvent e) {
      
    }
    
}
